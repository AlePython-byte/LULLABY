import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'ai-training/validation'))
import fidelity_v2 as fidelity
from run_fidelity_v2 import assert_godot_idle, record_attempt, save

p = ROOT / 'ai-training/reports/v3/gchandle_idle_reproduction_20261101_01'
p.mkdir(exist_ok=False)
(p / 'execution').mkdir()
protocol = fidelity.load_protocol()
authorization = p / 'authorization.json'
save(authorization, {'mode': 'acceptance', 'protocol_sha256': fidelity.PROTOCOL_SHA256,
    'user_approved': True, 'machine_confirmed_free': True,
    'approved_at_utc': datetime.now(timezone.utc).isoformat(),
    'diagnostic_only': True, 'first_seed': 610001, 'count': 5, 'runs': 10,
    'scope': 'Reproduction only, three independent attempts, no acceptance verdict or reserve combats.'})
fidelity.authorization(authorization, 'acceptance')
prior = json.loads((ROOT / 'ai-training/reports/v3/acceptance_v2_20261101_01/execution/state.json').read_text())
frozen = prior['config']['source_sha256']
assert all(fidelity.digest(ROOT / name) == value for name, value in frozen.items())
state = {'diagnostic_only': True, 'first_seed': 610001, 'levels': 5, 'runs': 10,
    'max_attempts': 3, 'worker_count': 1, 'tiered_compilation': 'unset',
    'gcConcurrent': 'unset', 'protocol_sha256': fidelity.PROTOCOL_SHA256,
    'authorization_sha256': fidelity.digest(authorization), 'started': time.time(),
    'source_sha256': frozen, 'provenance': fidelity.verify_sources(protocol),
    'decision_rule': 'Three whole-batch attempts; systematic if all invalid and at least one GCHandle context pair recurs in all three. Otherwise clean or sporadic. No fidelity aggregation.',
    'attempts': [], 'status': 'running'}
save(p / 'execution/state.json', state)
godot = Path(prior['config']['godot'])
env = os.environ.copy()
env.pop('DOTNET_TieredCompilation', None)
env.pop('DOTNET_gcConcurrent', None)
for number in range(1, 4):
    assert_godot_idle()
    assert all(fidelity.digest(ROOT / name) == value for name, value in frozen.items())
    batch = p / 'execution' / f'batch_610001_attempt_{number}'
    log = batch.with_suffix('.log')
    engine = batch.with_suffix('.engine.log')
    attempt = {'first_seed': 610001, 'level_count': 5, 'runs': 10, 'attempt': number,
        'folder': str(batch.relative_to(p)), 'log': str(log.relative_to(p)),
        'engine_log': str(engine.relative_to(p)), 'status': 'running'}
    command = [str(godot), '--headless', '--fixed-fps', '60', '--path', str(ROOT),
        '--log-file', str(engine), 'res://tests/FidelityV3V2Check.tscn', '--',
        '--mode=acceptance', f'--out-dir={batch}', '--first-seed=610001',
        '--level-count=5', f'--authorization-file={authorization}']
    attempt['command'] = command
    attempt['started'] = time.time()
    state['attempts'].append(attempt)
    save(p / 'execution/state.json', state)
    print(f'IDLE_BEGIN attempt={number}', flush=True)
    with log.open('x', encoding='utf-8') as out, (p / 'progress.log').open('a', encoding='utf-8') as progress:
        with subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace') as process:
            for line in process.stdout:
                out.write(line)
                out.flush()
                progress.write(line)
                progress.flush()
                if line.startswith(('V2_PAIR_END', 'ERROR:', 'V2_BATCH_COMPLETE', 'V2_QUALITY_FAILURE', 'V2_INTEGRITY_FAILURE')):
                    print(line.rstrip(), flush=True)
            code = process.wait()
    clean = record_attempt(p, attempt, code, protocol)
    if clean:
        fidelity.validate_batch(batch, 'acceptance', 610001, 5, 10, protocol)
    attempt['finished'] = time.time()
    save(p / 'execution/state.json', state)
    scan = attempt['channels']['log']
    print(f"IDLE_END attempt={number} status={attempt['status']} gchandle_lines={scan['gchandle_lines']}", flush=True)
    if attempt['quality_failure'] or attempt['integrity_failure']:
        state['status'] = 'blocked_quality_or_integrity'
        break
else:
    sets = [{(i['active_pair']['seed'], i['active_pair']['run']) for i in a['channels']['log']['blocking']
             if i.get('active_pair') and 'gchandle' in i.get('text', '').lower()} for a in state['attempts']]
    common = set.intersection(*sets)
    systematic = all(a['status'] == 'invalid' for a in state['attempts']) and bool(common)
    state['status'] = 'systematic_same_pair' if systematic else 'clean_or_sporadic'
    state['recurrent_gchandle_pairs'] = [{'seed': seed, 'run': run} for seed, run in sorted(common)]
state['finished'] = time.time()
save(p / 'execution/state.json', state)
print('IDLE_RESULT ' + json.dumps({'status': state['status'], 'common': state.get('recurrent_gchandle_pairs', [])}), flush=True)
